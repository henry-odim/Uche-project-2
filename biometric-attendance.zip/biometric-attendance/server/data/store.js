const { v4: uuidv4 } = require('uuid');

const students = [
  { id: 'STU001', name: 'Amara Okonkwo', course: 'Computer Science', year: 2, securityQuestion: 'What is your mother\'s maiden name?', securityAnswer: 'adeyemi' },
  { id: 'STU002', name: 'Chidi Eze', course: 'Electrical Engineering', year: 3, securityQuestion: 'What was the name of your first pet?', securityAnswer: 'bingo' },
  { id: 'STU003', name: 'Fatima Bello', course: 'Medicine', year: 1, securityQuestion: 'What city were you born in?', securityAnswer: 'kano' },
  { id: 'STU004', name: 'Emeka Nwosu', course: 'Business Administration', year: 4, securityQuestion: 'What is your mother\'s maiden name?', securityAnswer: 'obi' },
  { id: 'STU005', name: 'Ngozi Adeyemi', course: 'Law', year: 2, securityQuestion: 'What was the name of your first pet?', securityAnswer: 'lucky' },
];

const attendanceRecords = [
  { id: uuidv4(), studentId: 'STU001', studentName: 'Amara Okonkwo', course: 'Computer Science', timestamp: new Date(Date.now() - 86400000).toISOString(), location: { lat: 6.5244, lng: 3.3792, address: 'Lagos, Nigeria' }, faceVerified: true, gpsVerified: true, securityVerified: true, status: 'present' },
  { id: uuidv4(), studentId: 'STU002', studentName: 'Chidi Eze', course: 'Electrical Engineering', timestamp: new Date(Date.now() - 86400000).toISOString(), location: { lat: 6.5250, lng: 3.3800, address: 'Lagos, Nigeria' }, faceVerified: true, gpsVerified: true, securityVerified: true, status: 'present' },
  { id: uuidv4(), studentId: 'STU003', studentName: 'Fatima Bello', course: 'Medicine', timestamp: new Date(Date.now() - 172800000).toISOString(), location: { lat: 6.5244, lng: 3.3792, address: 'Lagos, Nigeria' }, faceVerified: true, gpsVerified: false, securityVerified: true, status: 'flagged' },
];

module.exports = { students, attendanceRecords, uuidv4 };
