const { v4: uuidv4 } = require('uuid');

const students = [
  { id: 'STU001', matricNo: '20220010011', name: 'Amara Okonkwo', course: 'Computer Science', year: 2, securityQuestion: 'What is your mother\'s maiden name?', securityAnswer: 'adeyemi' },
  { id: 'STU002', matricNo: '20210450022', name: 'Chidi Eze', course: 'Electrical Engineering', year: 3, securityQuestion: 'What was the name of your first pet?', securityAnswer: 'bingo' },
  { id: 'STU003', matricNo: '20230120033', name: 'Fatima Bello', course: 'Medicine', year: 1, securityQuestion: 'What city were you born in?', securityAnswer: 'kano' },
  { id: 'STU004', matricNo: '20200890044', name: 'Emeka Nwosu', course: 'Business Administration', year: 4, securityQuestion: 'What is your mother\'s maiden name?', securityAnswer: 'obi' },
  { id: 'STU005', matricNo: '20220330055', name: 'Ngozi Adeyemi', course: 'Law', year: 2, securityQuestion: 'What was the name of your first pet?', securityAnswer: 'lucky' },
];

const attendanceRecords = [
  { id: uuidv4(), studentId: 'STU001', studentName: 'Amara Okonkwo', course: 'Computer Science', timestamp: new Date(Date.now() - 86400000).toISOString(), location: { lat: 6.5244, lng: 3.3792, address: 'Lagos, Nigeria' }, faceVerified: true, gpsVerified: true, securityVerified: true, status: 'present' },
  { id: uuidv4(), studentId: 'STU002', studentName: 'Chidi Eze', course: 'Electrical Engineering', timestamp: new Date(Date.now() - 86400000).toISOString(), location: { lat: 6.5250, lng: 3.3800, address: 'Lagos, Nigeria' }, faceVerified: true, gpsVerified: true, securityVerified: true, status: 'present' },
  { id: uuidv4(), studentId: 'STU003', studentName: 'Fatima Bello', course: 'Medicine', timestamp: new Date(Date.now() - 172800000).toISOString(), location: { lat: 6.5244, lng: 3.3792, address: 'Lagos, Nigeria' }, faceVerified: true, gpsVerified: false, securityVerified: true, status: 'flagged' },
];

const lecturers = [
  { id: 'LEC001', name: 'Dr. Adaeze Obi', email: 'a.obi@uni.edu', password: 'lecturer123', department: 'Computer Science' },
  { id: 'LEC002', name: 'Prof. Kunle Adesanya', email: 'k.adesanya@uni.edu', password: 'lecturer123', department: 'Engineering' },
];

// Active attendance sessions created by lecturers
// { id, shortCode, lecturerId, lecturerName, course, securityQuestion, securityAnswer, expiresAt, createdAt }
const sessions = [];

module.exports = { students, attendanceRecords, lecturers, sessions, uuidv4 };
