const express = require('express');
const cors = require('cors');
const path = require('path');

const attendanceRoutes = require('./routes/attendance');
const authRoutes = require('./routes/auth');
const sessionRoutes = require('./routes/sessions');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '../public')));

app.use('/api/attendance', attendanceRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/sessions', sessionRoutes);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/pages/checkin.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/pages/admin.html'));
});

app.get('/lecturer', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/pages/lecturer.html'));
});

// Short URL redirect — /s/ABC123 → check-in page with session code
app.get('/s/:code', (req, res) => {
  res.redirect(`/?session=${req.params.code.toUpperCase()}`);
});

app.listen(PORT, () => {
  console.log(`Biometric Attendance System running at http://localhost:${PORT}`);
});
