const express = require('express');
const cors = require('cors');
const path = require('path');

const attendanceRoutes = require('./routes/attendance');
const authRoutes = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '../public')));

app.use('/api/attendance', attendanceRoutes);
app.use('/api/auth', authRoutes);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/pages/checkin.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/pages/admin.html'));
});

app.listen(PORT, () => {
  console.log(`Biometric Attendance System running at http://localhost:${PORT}`);
});
