const express = require('express');
const router = express.Router();
const { students, attendanceRecords, uuidv4 } = require('../data/store');

// GET all attendance records
router.get('/', (req, res) => {
  const sorted = [...attendanceRecords].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  res.json({ success: true, records: sorted });
});

// GET summary stats
router.get('/stats', (req, res) => {
  const today = new Date().toDateString();
  const todayRecords = attendanceRecords.filter(r => new Date(r.timestamp).toDateString() === today);
  const presentToday = todayRecords.filter(r => r.status === 'present').length;
  const flaggedToday = todayRecords.filter(r => r.status === 'flagged').length;

  res.json({
    success: true,
    stats: {
      totalStudents: students.length,
      presentToday,
      flaggedToday,
      totalRecords: attendanceRecords.length,
    }
  });
});

// POST submit attendance
router.post('/submit', (req, res) => {
  const { studentId, faceCapture, location, securityAnswer } = req.body;

  const student = students.find(s => s.id === studentId);
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }

  // Check if already checked in today
  const today = new Date().toDateString();
  const alreadyCheckedIn = attendanceRecords.find(
    r => r.studentId === studentId && new Date(r.timestamp).toDateString() === today
  );
  if (alreadyCheckedIn) {
    return res.status(409).json({ success: false, message: 'You have already checked in today.' });
  }

  // Verify security answer
  const securityVerified = securityAnswer.trim().toLowerCase() === student.securityAnswer.toLowerCase();
  if (!securityVerified) {
    return res.status(401).json({ success: false, message: 'Security answer is incorrect.' });
  }

  // Simulate face verification (in production, integrate a face recognition API)
  const faceVerified = !!faceCapture;

  // Simulate GPS verification — check if within ~5km of campus (Lagos coords example)
  const campusLat = 6.5244;
  const campusLng = 3.3792;
  const gpsVerified = location
    ? getDistanceKm(location.lat, location.lng, campusLat, campusLng) <= 5
    : false;

  const status = faceVerified && gpsVerified && securityVerified ? 'present' : 'flagged';

  const record = {
    id: uuidv4(),
    studentId: student.id,
    studentName: student.name,
    course: student.course,
    timestamp: new Date().toISOString(),
    location: location || null,
    faceVerified,
    gpsVerified,
    securityVerified,
    status,
  };

  attendanceRecords.push(record);

  res.json({
    success: true,
    message: status === 'present' ? 'Attendance recorded successfully.' : 'Attendance recorded but flagged for review.',
    record,
  });
});

function getDistanceKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function toRad(deg) { return deg * Math.PI / 180; }

module.exports = router;
