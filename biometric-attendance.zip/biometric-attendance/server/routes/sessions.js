const express = require('express');
const router = express.Router();
const { sessions, lecturers, attendanceRecords, uuidv4 } = require('../data/store');

function generateShortCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// POST create a new session
router.post('/create', (req, res) => {
  const { lecturerId, course, securityQuestion, securityAnswer, durationMinutes } = req.body;

  if (!lecturerId || !course || !securityQuestion || !securityAnswer || !durationMinutes) {
    return res.status(400).json({ success: false, message: 'All fields are required.' });
  }

  const lecturer = lecturers.find(l => l.id === lecturerId);
  if (!lecturer) return res.status(404).json({ success: false, message: 'Lecturer not found.' });

  const shortCode = generateShortCode();
  const expiresAt = new Date(Date.now() + durationMinutes * 60 * 1000).toISOString();

  const session = {
    id: uuidv4(),
    shortCode,
    lecturerId,
    lecturerName: lecturer.name,
    course,
    securityQuestion,
    securityAnswer: securityAnswer.trim().toLowerCase(),
    durationMinutes,
    expiresAt,
    createdAt: new Date().toISOString(),
  };

  sessions.push(session);

  res.json({ success: true, session: safeSession(session) });
});

// GET sessions by lecturer
router.get('/lecturer/:lecturerId', (req, res) => {
  const lecturerSessions = sessions
    .filter(s => s.lecturerId === req.params.lecturerId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(safeSession);
  res.json({ success: true, sessions: lecturerSessions });
});

// GET session by short code (used by student check-in page)
router.get('/code/:code', (req, res) => {
  const session = sessions.find(s => s.shortCode === req.params.code.toUpperCase());
  if (!session) return res.status(404).json({ success: false, message: 'Session not found.' });

  const expired = new Date() > new Date(session.expiresAt);
  if (expired) return res.status(410).json({ success: false, message: 'This session has expired.' });

  res.json({ success: true, session: safeSession(session) });
});

// GET attendance records for a specific session
router.get('/:sessionId/records', (req, res) => {
  const session = sessions.find(s => s.id === req.params.sessionId);
  if (!session) return res.status(404).json({ success: false, message: 'Session not found.' });

  const records = attendanceRecords
    .filter(r => r.sessionId === req.params.sessionId)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  res.json({ success: true, records });
});

// DELETE (end) a session early
router.delete('/:sessionId', (req, res) => {
  const idx = sessions.findIndex(s => s.id === req.params.sessionId);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Session not found.' });
  sessions[idx].expiresAt = new Date().toISOString();
  res.json({ success: true, message: 'Session ended.' });
});

function safeSession(s) {
  const { securityAnswer, ...safe } = s;
  safe.expired = new Date() > new Date(s.expiresAt);
  return safe;
}

module.exports = router;
