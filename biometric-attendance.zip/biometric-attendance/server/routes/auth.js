const express = require('express');
const router = express.Router();
const { students } = require('../data/store');

// GET student by ID (returns question only, not answer)
router.get('/student/:id', (req, res) => {
  const student = students.find(s => s.id === req.params.id.toUpperCase());
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student ID not found.' });
  }
  res.json({
    success: true,
    student: {
      id: student.id,
      name: student.name,
      course: student.course,
      year: student.year,
      securityQuestion: student.securityQuestion,
    }
  });
});

// POST admin login (simple password check — replace with proper auth in production)
router.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'admin123') {
    res.json({ success: true, token: 'mock-admin-token-123' });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }
});

module.exports = router;
