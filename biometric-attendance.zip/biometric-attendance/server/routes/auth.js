const express = require('express');
const router = express.Router();
const { students, lecturers } = require('../data/store');

// POST student lookup by name + matric number
router.post('/student/lookup', (req, res) => {
  const { name, matricNo } = req.body;
  if (!name || !matricNo) {
    return res.status(400).json({ success: false, message: 'Please provide both your name and matric number.' });
  }

  if (!/^\d{11}$/.test(matricNo.trim())) {
    return res.status(400).json({ success: false, message: 'Matric number must be exactly 11 digits.' });
  }

  const student = students.find(s =>
    s.matricNo.toLowerCase() === matricNo.trim().toLowerCase() &&
    s.name.toLowerCase().includes(name.trim().toLowerCase())
  );

  if (!student) {
    return res.status(404).json({ success: false, message: 'No student found with that name and matric number. Please check your details.' });
  }

  res.json({
    success: true,
    student: {
      id: student.id,
      matricNo: student.matricNo,
      name: student.name,
      course: student.course,
      year: student.year,
      securityQuestion: student.securityQuestion,
    }
  });
});

// POST admin login (simple password check — replace with proper auth in production)
router.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'admin123') {
    res.json({ success: true, token: 'mock-admin-token-123' });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }
});

// POST lecturer login
router.post('/lecturer/login', (req, res) => {
  const { email, password } = req.body;
  const lecturer = lecturers.find(l => l.email === email && l.password === password);
  if (!lecturer) {
    return res.status(401).json({ success: false, message: 'Invalid email or password.' });
  }
  res.json({
    success: true,
    token: `mock-lecturer-token-${lecturer.id}`,
    lecturer: { id: lecturer.id, name: lecturer.name, email: lecturer.email, department: lecturer.department },
  });
});

module.exports = router;
