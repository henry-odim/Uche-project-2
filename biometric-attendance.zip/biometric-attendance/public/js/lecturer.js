let lecturerData = null;
let activeSession = null;
let countdownTimer = null;
let currentTab = 'create';

// ── Auth ──
async function doLogin() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();
  if (!email || !password) return showLoginAlert('Please enter your email and password.');

  const btn = document.getElementById('btn-login');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Signing in…';

  try {
    const res = await fetch('/api/auth/lecturer/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!data.success) {
      btn.disabled = false;
      btn.textContent = 'Sign in';
      return showLoginAlert(data.message);
    }

    lecturerData = data.lecturer;
    sessionStorage.setItem('lecturerData', JSON.stringify(lecturerData));
    initDashboard();
  } catch {
    btn.disabled = false;
    btn.textContent = 'Sign in';
    showLoginAlert('Could not connect to the server.');
  }
}

document.getElementById('password').addEventListener('keydown', e => {
  if (e.key === 'Enter') doLogin();
});

function showLoginAlert(msg) {
  const el = document.getElementById('login-alert');
  el.className = 'alert alert-danger show';
  el.innerHTML = `<span>✕</span> ${msg}`;
}

function logout() {
  sessionStorage.removeItem('lecturerData');
  location.reload();
}

function initDashboard() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  document.getElementById('welcome-name').textContent = `Welcome, ${lecturerData.name.split(' ')[0]}`;
}

const stored = sessionStorage.getItem('lecturerData');
if (stored) { lecturerData = JSON.parse(stored); initDashboard(); }

// ── Tabs ──
function showTab(tab) {
  currentTab = tab;
  document.getElementById('tab-create').classList.toggle('hidden', tab !== 'create');
  document.getElementById('tab-sessions').classList.toggle('hidden', tab !== 'sessions');
  document.querySelectorAll('.tab-btn').forEach((btn, i) => {
    btn.classList.toggle('active', (i === 0 && tab === 'create') || (i === 1 && tab === 'sessions'));
  });
  if (tab === 'sessions') loadSessions();
}

// ── Create session ──
async function createSession() {
  const course = document.getElementById('course').value.trim();
  const duration = parseInt(document.getElementById('duration').value);
  const securityQuestion = document.getElementById('sec-question').value.trim();
  const securityAnswer = document.getElementById('sec-answer').value.trim();

  if (!course || !securityQuestion || !securityAnswer) {
    const el = document.getElementById('create-alert');
    el.className = 'alert alert-danger show';
    el.innerHTML = '<span>✕</span> Please fill in all fields.';
    return;
  }

  const btn = document.getElementById('btn-create');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Creating…';

  try {
    const res = await fetch('/api/sessions/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lecturerId: lecturerData.id, course, securityQuestion, securityAnswer, durationMinutes: duration }),
    });
    const data = await res.json();
    btn.disabled = false;
    btn.textContent = 'Generate QR code & link →';

    if (!data.success) {
      const el = document.getElementById('create-alert');
      el.className = 'alert alert-danger show';
      el.innerHTML = `<span>✕</span> ${data.message}`;
      return;
    }

    activeSession = data.session;
    openModal(data.session);
  } catch {
    btn.disabled = false;
    btn.textContent = 'Generate QR code & link →';
  }
}

// ── QR Modal ──
function openModal(session) {
  const base = window.location.origin;
  const url = `${base}/s/${session.shortCode}`;

  document.getElementById('modal-title').textContent = 'Session created ✓';
  document.getElementById('modal-course').textContent = session.course;
  document.getElementById('modal-url').textContent = url;
  document.getElementById('modal-code').textContent = session.shortCode;

  // Generate QR code
  document.getElementById('qr-code').innerHTML = '';
  new QRCode(document.getElementById('qr-code'), {
    text: url,
    width: 200,
    height: 200,
    colorDark: '#111827',
    colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.M,
  });

  document.getElementById('qr-modal').classList.remove('hidden');
  startCountdown(session.expiresAt);
}

function closeModal() {
  document.getElementById('qr-modal').classList.add('hidden');
  clearInterval(countdownTimer);
}

function startCountdown(expiresAt) {
  function update() {
    const ms = new Date(expiresAt) - new Date();
    if (ms <= 0) {
      document.getElementById('modal-countdown').textContent = 'Session expired';
      clearInterval(countdownTimer);
      return;
    }
    const m = Math.floor(ms / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    document.getElementById('modal-countdown').textContent =
      `Expires in ${m}m ${s.toString().padStart(2, '0')}s`;
  }
  update();
  countdownTimer = setInterval(update, 1000);
}

function copyUrl() {
  const url = document.getElementById('modal-url').textContent;
  navigator.clipboard.writeText(url).then(() => {
    const btn = event.target;
    const original = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(() => { btn.textContent = original; }, 2000);
  });
}

// ── My sessions ──
async function loadSessions() {
  const container = document.getElementById('sessions-list');
  try {
    const res = await fetch(`/api/sessions/lecturer/${lecturerData.id}`);
    const data = await res.json();
    if (!data.sessions.length) {
      container.innerHTML = '<p style="color:var(--gray-400);font-size:14px;text-align:center;padding:2rem;">No sessions yet. Create one from the "New session" tab.</p>';
      return;
    }

    container.innerHTML = data.sessions.map(s => {
      const created = new Date(s.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      const expires = new Date(s.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const base = window.location.origin;
      const url = `${base}/s/${s.shortCode}`;

      return `
        <div class="card card-sm session-card ${s.expired ? 'expired' : ''}" style="margin-bottom:1rem;">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
            <div style="flex:1;min-width:200px;">
              <div style="font-weight:600;font-size:15px;margin-bottom:4px;">${s.course}</div>
              <div style="font-size:13px;color:var(--gray-400);">Created ${created} · Expires ${expires}</div>
              <div style="font-size:13px;color:var(--gray-600);margin-top:6px;">Code: <strong style="letter-spacing:2px;">${s.shortCode}</strong></div>
            </div>
            <div style="display:flex;gap:8px;flex-shrink:0;align-items:center;">
              <span class="session-status ${s.expired ? '' : 'badge badge-success'}">${s.expired ? 'Expired' : '● Active'}</span>
              ${!s.expired ? `<button class="btn btn-outline btn-sm" onclick="showSessionQR(${JSON.stringify(s).replace(/"/g, '&quot;')})">View QR</button>` : ''}
              ${!s.expired ? `<button class="btn btn-outline btn-sm" style="color:var(--red)" onclick="endSession('${s.id}')">End</button>` : ''}
            </div>
          </div>
          <div class="divider" style="margin:12px 0;"></div>
          <div style="font-size:12px;color:var(--gray-400);word-break:break-all;">
            🔗 <a href="${url}" target="_blank" style="color:var(--blue);text-decoration:none;">${url}</a>
          </div>
        </div>
      `;
    }).join('');
  } catch {
    container.innerHTML = '<p style="color:var(--red);text-align:center;padding:2rem;">Failed to load sessions.</p>';
  }
}

function showSessionQR(session) {
  openModal(session);
}

async function endSession(sessionId) {
  if (!confirm('End this session? Students will no longer be able to check in.')) return;
  await fetch(`/api/sessions/${sessionId}`, { method: 'DELETE' });
  loadSessions();
}
