let allRecords = [];

// ── Login ──
async function adminLogin() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();

  if (!username || !password) return showLoginAlert('Please enter your credentials.');

  const btn = document.getElementById('btn-login');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner" style="border-top-color:white;"></span> Signing in…';

  try {
    const res = await fetch('/api/auth/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });

    const data = await res.json();
    if (!data.success) {
      btn.disabled = false;
      btn.textContent = 'Sign in';
      return showLoginAlert(data.message);
    }

    sessionStorage.setItem('adminToken', data.token);
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    loadStats();
    loadRecords();
  } catch (e) {
    btn.disabled = false;
    btn.textContent = 'Sign in';
    showLoginAlert('Could not connect to the server.');
  }
}

document.getElementById('password').addEventListener('keydown', e => {
  if (e.key === 'Enter') adminLogin();
});

function showLoginAlert(msg) {
  const el = document.getElementById('login-alert');
  el.className = 'alert alert-danger show';
  el.innerHTML = `<span>✕</span> ${msg}`;
}

function logout() {
  sessionStorage.removeItem('adminToken');
  location.reload();
}

// Check if already logged in
if (sessionStorage.getItem('adminToken')) {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  loadStats();
  loadRecords();
}

// ── Stats ──
async function loadStats() {
  try {
    const res = await fetch('/api/attendance/stats');
    const data = await res.json();
    if (!data.success) return;
    const s = data.stats;
    document.getElementById('stat-total').textContent = s.totalStudents;
    document.getElementById('stat-present').textContent = s.presentToday;
    document.getElementById('stat-flagged').textContent = s.flaggedToday;
    document.getElementById('stat-records').textContent = s.totalRecords;
  } catch (e) {
    console.error('Stats load failed', e);
  }
}

// ── Records ──
async function loadRecords() {
  try {
    const res = await fetch('/api/attendance');
    const data = await res.json();
    if (!data.success) return;
    allRecords = data.records;
    renderTable(allRecords);
  } catch (e) {
    document.getElementById('table-body').innerHTML =
      '<tr><td colspan="7" style="text-align:center;color:var(--red);padding:2rem;">Failed to load records.</td></tr>';
  }
}

function renderTable(records) {
  const tbody = document.getElementById('table-body');

  if (!records.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray-400);padding:2rem;">No records found.</td></tr>';
    return;
  }

  tbody.innerHTML = records.map(r => {
    const time = new Date(r.timestamp).toLocaleString([], {
      month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });

    const tick = '<span class="tick">✓</span>';
    const cross = '<span class="cross">✕</span>';

    const statusBadge = r.status === 'present'
      ? '<span class="badge badge-success">● Present</span>'
      : '<span class="badge badge-warning">⚠ Flagged</span>';

    return `
      <tr>
        <td><strong style="font-size:14px;">${r.studentName}</strong><br><small style="color:var(--gray-400)">${r.studentId}</small></td>
        <td style="color:var(--gray-600)">${r.course}</td>
        <td style="color:var(--gray-600);font-size:13px;">${time}</td>
        <td>${r.faceVerified ? tick : cross}</td>
        <td>${r.gpsVerified ? tick : cross}</td>
        <td>${r.securityVerified ? tick : cross}</td>
        <td>${statusBadge}</td>
      </tr>
    `;
  }).join('');
}

function filterTable() {
  const search = document.getElementById('search').value.toLowerCase();
  const status = document.getElementById('filter-status').value;

  const filtered = allRecords.filter(r => {
    const matchSearch = r.studentName.toLowerCase().includes(search) ||
                        r.course.toLowerCase().includes(search) ||
                        r.studentId.toLowerCase().includes(search);
    const matchStatus = !status || r.status === status;
    return matchSearch && matchStatus;
  });

  renderTable(filtered);
}
