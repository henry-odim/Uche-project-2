let currentStep = 1;
let studentData = null;
let faceCapture = null;
let locationData = null;
let stream = null;
let sessionData = null; // populated if arriving via QR/short link

// Detect ?session= param in URL and load session
(async function detectSession() {
  const params = new URLSearchParams(window.location.search);
  const code = params.get('session');
  if (!code) return;

  try {
    const res = await fetch(`/api/sessions/code/${code}`);
    const data = await res.json();
    if (!data.success) {
      showAlert(data.message || 'Session not found or expired.', 'warning');
      return;
    }
    sessionData = data.session;

    // Show session banner
    const banner = document.createElement('div');
    banner.className = 'alert alert-warning show';
    banner.style.marginBottom = '1rem';
    banner.innerHTML = `<span>📋</span> <strong>${sessionData.course}</strong> — session by ${sessionData.lecturerName}. Expires at ${new Date(sessionData.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`;
    document.querySelector('.container').insertBefore(banner, document.getElementById('steps'));

    // Pre-fill the security question label
    document.getElementById('security-question-label').textContent = sessionData.securityQuestion;
  } catch {
    // silently ignore if session lookup fails
  }
})();

function showAlert(msg, type = 'danger') {
  const el = document.getElementById('alert');
  el.className = `alert alert-${type} show`;
  el.innerHTML = `<span>${type === 'success' ? '✓' : type === 'warning' ? '⚠' : '✕'}</span> ${msg}`;
  setTimeout(() => el.classList.remove('show'), 5000);
}

function goToStep(n) {
  document.getElementById(`panel-${currentStep}`).classList.add('hidden');
  document.getElementById(`step-${currentStep}`).classList.remove('active');
  document.getElementById(`step-${currentStep}`).classList.add('done');
  currentStep = n;
  document.getElementById(`panel-${n}`).classList.remove('hidden');
  document.getElementById(`step-${n}`).classList.add('active');
}

// ── Step 1: Lookup student ──
async function lookupStudent() {
  const name = document.getElementById('studentName').value.trim();
  const matricNo = document.getElementById('matricNo').value.trim();
  if (!name || !matricNo) return showAlert('Please enter both your name and matric number.');
  if (!/^\d{11}$/.test(matricNo)) return showAlert('Matric number must be exactly 11 digits.');

  try {
    const res = await fetch('/api/auth/student/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, matricNo }),
    });
    const data = await res.json();
    if (!data.success) return showAlert(data.message);

    studentData = data.student;
    document.getElementById('student-name').textContent = studentData.name;
    document.getElementById('student-course').textContent = `${studentData.course} · Year ${studentData.year} · ${studentData.matricNo}`;
    document.getElementById('student-info').classList.remove('hidden');
    // Use lecturer's session question if in session mode, else student's own question
    if (!sessionData) {
      document.getElementById('security-question-label').textContent = studentData.securityQuestion;
    }

    setTimeout(() => goToStep(2), 600);
  } catch (e) {
    showAlert('Could not connect to the server. Make sure it is running.');
  }
}

document.getElementById('matricNo').addEventListener('keydown', e => {
  if (e.key === 'Enter') lookupStudent();
});

// ── Step 2: Camera ──
async function startCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
    const video = document.getElementById('video');
    video.srcObject = stream;
    video.style.display = 'block';
    document.getElementById('camera-placeholder').style.display = 'none';
    document.getElementById('btn-start-cam').classList.add('hidden');
    document.getElementById('btn-capture').classList.remove('hidden');
  } catch (e) {
    showAlert('Camera access denied. Please allow camera permissions and try again.');
  }
}

function capturePhoto() {
  const video = document.getElementById('video');
  const canvas = document.getElementById('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);

  faceCapture = canvas.toDataURL('image/jpeg', 0.7);

  video.style.display = 'none';
  canvas.style.display = 'block';

  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = null;

  document.getElementById('btn-capture').classList.add('hidden');
  document.getElementById('btn-retake').classList.remove('hidden');
  document.getElementById('btn-next-2').classList.remove('hidden');
  showAlert('Photo captured! Looking good.', 'success');
}

function retakePhoto() {
  faceCapture = null;
  const canvas = document.getElementById('canvas');
  canvas.style.display = 'none';
  document.getElementById('btn-retake').classList.add('hidden');
  document.getElementById('btn-next-2').classList.add('hidden');
  document.getElementById('btn-start-cam').classList.remove('hidden');
  document.getElementById('camera-placeholder').style.display = 'flex';
}

// ── Step 3: GPS ──
function getLocation() {
  const icon = document.getElementById('gps-icon');
  const status = document.getElementById('gps-status');
  const item = document.getElementById('gps-item');

  icon.textContent = '⏳';
  item.classList.add('active');
  status.textContent = 'Detecting…';

  if (!navigator.geolocation) {
    status.textContent = 'Not supported';
    item.classList.add('failed');
    icon.textContent = '✕';
    return showAlert('Geolocation is not supported by your browser.');
  }

  navigator.geolocation.getCurrentPosition(
    pos => {
      locationData = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      icon.textContent = '✓';
      item.classList.remove('active');
      item.classList.add('done');
      status.textContent = `${locationData.lat.toFixed(4)}, ${locationData.lng.toFixed(4)}`;
      document.getElementById('btn-next-3').classList.remove('hidden');
      showAlert('Location captured successfully.', 'success');
    },
    err => {
      icon.textContent = '✕';
      item.classList.remove('active');
      item.classList.add('failed');
      status.textContent = 'Access denied';
      showAlert('Location access denied. GPS verification will be marked as failed.');
      document.getElementById('btn-next-3').classList.remove('hidden');
    },
    { timeout: 10000 }
  );
}

// ── Step 4: Submit ──
async function submitAttendance() {
  const answer = document.getElementById('security-answer').value.trim();
  if (!answer) return showAlert('Please answer the security question.');

  const btn = document.getElementById('btn-submit');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Submitting…';

  try {
    const res = await fetch('/api/attendance/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: studentData.id,
        faceCapture,
        location: locationData,
        securityAnswer: answer,
        sessionCode: sessionData ? sessionData.shortCode : null,
      }),
    });

    const data = await res.json();

    if (!data.success) {
      btn.disabled = false;
      btn.textContent = 'Submit attendance';
      return showAlert(data.message);
    }

    showSuccess(data.record);
  } catch (e) {
    btn.disabled = false;
    btn.textContent = 'Submit attendance';
    showAlert('Submission failed. Please check your connection.');
  }
}

document.getElementById('security-answer').addEventListener('keydown', e => {
  if (e.key === 'Enter') submitAttendance();
});

function showSuccess(record) {
  ['panel-4', 'steps'].forEach(id => document.getElementById(id).classList.add('hidden'));
  document.getElementById('panel-success').classList.remove('hidden');

  const time = new Date(record.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  document.getElementById('success-msg').textContent =
    record.status === 'present'
      ? `All checks passed. Recorded at ${time}.`
      : `Recorded at ${time}, but flagged for admin review (some checks failed).`;

  document.getElementById('summary-list').innerHTML = `
    <div style="display:flex;flex-direction:column;gap:8px;margin-top:0.5rem;">
      <div>${record.faceVerified ? '✅' : '❌'} Face ID verification</div>
      <div>${record.gpsVerified ? '✅' : '❌'} GPS location check</div>
      <div>${record.securityVerified ? '✅' : '❌'} Security question</div>
    </div>
  `;
}

function resetForm() {
  location.reload();
}
