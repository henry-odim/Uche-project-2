# UniAttend — Biometric Attendance System

A university attendance system using Face ID (webcam capture), GPS location, and security questions.

## Tech Stack

- **Frontend**: Plain HTML, CSS, JavaScript
- **Backend**: Node.js + Express

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Start the server

```bash
# Production
npm start

# Development (auto-restarts on file changes)
npm run dev
```

### 3. Open in browser

```
http://localhost:3000        → Student check-in page
http://localhost:3000/admin  → Admin dashboard
```

## Default Credentials

**Admin login:**
- Username: `admin`
- Password: `admin123`

**Sample student IDs** (for testing check-in):
- `STU001` — Amara Okonkwo
- `STU002` — Chidi Eze
- `STU003` — Fatima Bello
- `STU004` — Emeka Nwosu
- `STU005` — Ngozi Adeyemi

Each student's security answer is set in `server/data/store.js`.

## Project Structure

```
biometric-attendance/
├── server/
│   ├── index.js              # Express server entry point
│   ├── data/
│   │   └── store.js          # In-memory student & attendance data
│   └── routes/
│       ├── attendance.js     # Attendance API routes
│       └── auth.js           # Student lookup & admin login
├── public/
│   ├── css/
│   │   └── style.css         # Shared styles
│   ├── js/
│   │   ├── checkin.js        # Check-in page logic
│   │   └── admin.js          # Admin dashboard logic
│   └── pages/
│       ├── checkin.html      # Student check-in page
│       └── admin.html        # Admin dashboard
├── package.json
└── README.md
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/auth/student/:id` | Look up student by ID |
| POST | `/api/auth/admin/login` | Admin login |
| GET | `/api/attendance` | Get all attendance records |
| GET | `/api/attendance/stats` | Get summary statistics |
| POST | `/api/attendance/submit` | Submit attendance |

## Verification Logic

- **Face ID**: Webcam photo is captured and sent to the server. In production, wire this to a face recognition API (e.g. AWS Rekognition, Azure Face API).
- **GPS**: Student's coordinates are checked against a configurable campus location. Default campus is set to Lagos, Nigeria (6.5244, 3.3792). Edit in `server/routes/attendance.js`.
- **Security question**: Answer is compared case-insensitively against the stored answer.

A record is marked **present** if all three checks pass, or **flagged** if any fail.

## Production Notes

- Replace in-memory `store.js` with a real database (e.g. PostgreSQL, MongoDB).
- Replace mock admin auth with JWT + bcrypt.
- Integrate a real face recognition API for actual biometric verification.
- Set campus GPS coordinates to your actual institution's location.
- Add HTTPS — camera and GPS APIs require a secure context in production.
